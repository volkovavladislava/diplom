package com.example.mydiplom.data

data class KindOfMarkValues(
    val id: Int,
    val kind_of_mark_id: Int,
    val value: String
)
