package com.example.mydiplom.data

data class Prompt(
    val id: Int,
    val userId: Int,
    val name: String,
    val description: String,
    val date: String
)
