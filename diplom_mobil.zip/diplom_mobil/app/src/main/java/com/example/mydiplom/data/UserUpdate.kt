package com.example.mydiplom.data

data class UserUpdate(
    val userId: Int,
    val name: String,
    val height: Int,
    val weight: Int,
    val date_birth: String
)
