package com.example.mydiplom.data

data class PromptUpdate(
    val name: String,
    val description: String,
    val date: String
)
