package com.example.mydiplom.data

data class File(
    val id: Int,
    val userId: Int,
    val link: String,
    val mime_type: String,
    val date: String,
    val name: String,
    val comment: String

)
