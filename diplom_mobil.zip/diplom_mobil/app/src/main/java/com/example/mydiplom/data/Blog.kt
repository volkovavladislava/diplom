package com.example.mydiplom.data

data class Blog(
    val id: Int,
    val title: String,
    val description: String,
    val link: String
)
