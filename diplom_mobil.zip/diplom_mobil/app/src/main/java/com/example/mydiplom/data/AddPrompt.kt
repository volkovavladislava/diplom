package com.example.mydiplom.data

data class AddPrompt(
    val userId: Int,
    val name: String,
    val description: String,
    val date: String
)
