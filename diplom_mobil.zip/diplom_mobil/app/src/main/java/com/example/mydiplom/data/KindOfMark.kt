package com.example.mydiplom.data

data class KindOfMark(
    val id: Int,
    val name: String,
    val enum_kind_of_mark_id: Int
)
